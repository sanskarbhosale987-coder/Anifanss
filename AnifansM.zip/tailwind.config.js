module.exports = {
  content: ["./pages/*.{html,js}", "./index.html", "./js/*.js"],
  theme: {
    extend: {
      colors: {
        // Primary Colors
        primary: "#000000", // pure-black
        secondary: "#1A1A1A", // dark-gray-900
        accent: "#FF6B35", // orange-500
        
        // Background Colors
        background: "#0D0D0D", // near-black
        surface: "#2D2D2D", // gray-800
        
        // Text Colors
        "text-primary": "#FFFFFF", // white
        "text-secondary": "#B3B3B3", // gray-400
        
        // Status Colors
        success: "#00D084", // green-400
        warning: "#FFB020", // yellow-400
        error: "#FF4757", // red-400
        
        // Border Colors
        border: "#2D2D2D", // gray-800
        
        // Additional Shades for Flexibility
        "accent-light": "#FF8A5B", // orange-400
        "accent-dark": "#E55A2B", // orange-600
        "surface-light": "#3D3D3D", // gray-700
        "surface-dark": "#1D1D1D", // gray-900
      },
      fontFamily: {
        inter: ['Inter', 'sans-serif'],
        'source-sans': ['Source Sans Pro', 'sans-serif'],
        'noto-jp': ['Noto Sans JP', 'sans-serif'],
        sans: ['Source Sans Pro', 'sans-serif'],
      },
      fontWeight: {
        normal: '400',
        semibold: '600',
        bold: '700',
      },
      boxShadow: {
        'anime': '0 4px 12px rgba(0, 0, 0, 0.4)',
        'subtle': '0 2px 8px rgba(0, 0, 0, 0.3)',
        'hover': '0 8px 24px rgba(0, 0, 0, 0.5)',
      },
      animation: {
        'fade-in': 'fadeIn 300ms ease-out',
        'slide-up': 'slideUp 300ms ease-out',
        'scale-in': 'scaleIn 200ms ease-out',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { transform: 'translateY(20px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
        scaleIn: {
          '0%': { transform: 'scale(0.95)', opacity: '0' },
          '100%': { transform: 'scale(1)', opacity: '1' },
        },
      },
      transitionDuration: {
        '200': '200ms',
        '300': '300ms',
      },
      transitionTimingFunction: {
        'out': 'ease-out',
      },
      spacing: {
        '18': '4.5rem',
        '88': '22rem',
        '128': '32rem',
      },
      borderRadius: {
        'xl': '1rem',
        '2xl': '1.5rem',
      },
      backdropBlur: {
        'xs': '2px',
      },
    },
  },
  plugins: [],
}